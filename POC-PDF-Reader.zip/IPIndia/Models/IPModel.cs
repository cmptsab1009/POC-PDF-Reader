﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IPIndia.Models
{
    public class IPModel
    {
        public string Text { get; set; }
        public string Image { get; set; }
    }
}