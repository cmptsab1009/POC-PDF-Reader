﻿using IPIndia.Comman;
using IPIndia.Models;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace IPIndia.Controllers
{
    public class HomeController : Controller
    {
        protected override JsonResult Json(object data, string contentType, System.Text.Encoding contentEncoding, JsonRequestBehavior behavior)
        {
            return new JsonResult()
            {
                Data = data,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
                JsonRequestBehavior = behavior,
                MaxJsonLength = Int32.MaxValue
            };
        }

        public ActionResult Index()
        {
            return View();
        }
               
        public ActionResult UploadFiles()
        {             
            if (Request.Files.Count > 0)
            {
                try
                {
                    HttpFileCollectionBase files = Request.Files;
                    HttpPostedFileBase file = files[0];
                    using (var stream = file.InputStream)
                    {
                        //PdfImageExtractor.ExtractImages(stream, 12);
                        // Returns message that successfully uploaded  
                        return Json(new { result = PDFCompress2(stream), statusId = 1 }, JsonRequestBehavior.AllowGet);
                    }                
                }
                catch (Exception ex)
                {
                    return Json(new { result = "Error occurred. Error details: " + ex.Message, statusId = -99 }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { result = "No files selected.", statusId = -99 }, JsonRequestBehavior.AllowGet);              
            }
        }     

        private string PDFCompress2(Stream fileStream)
        {
            StringBuilder sb = new StringBuilder();
            BinaryReader br = new BinaryReader(fileStream);
            byte[] byt = br.ReadBytes((int)fileStream.Length);
            MemoryStream ms = new MemoryStream();

            PdfReader pdf = new PdfReader(byt);
            if (pdf.IsOpenedWithFullPermissions)
            {
                PdfStamper stp = new PdfStamper(pdf, ms);
                PdfWriter writer = stp.Writer;
                sb.Append("<table class='table' style='overflow-y:auto; height: 400px;'><tr><th>Text</th><th>Image</th></tr>");
                sb.AppendLine("<tr>");
                for (int i = 1; i <= pdf.NumberOfPages; i++)
                {
                    sb.Append("<td>" + PdfTextExtractor.GetTextFromPage(pdf, i) + "</td>");

                    PdfDictionary pg = pdf.GetPageN(i);
                    PdfDictionary res = (PdfDictionary)PdfReader.GetPdfObject(pg.Get(PdfName.RESOURCES));
                    PdfDictionary xobj = (PdfDictionary)PdfReader.GetPdfObject(res.Get(PdfName.XOBJECT));
                    if (xobj != null)
                    {
                        foreach (PdfName name in xobj.Keys)
                        {
                            PdfObject obj = xobj.Get(name);
                            if (obj.IsIndirect())
                            {
                                PdfDictionary tg = (PdfDictionary)PdfReader.GetPdfObject(obj);
                                PdfName type = (PdfName)PdfReader.GetPdfObject(tg.Get(PdfName.SUBTYPE));
                                if (PdfName.IMAGE.Equals(type))
                                {
                                    int xrefIdx = ((PRIndirectReference)obj).Number;
                                    PdfObject pdfObj = pdf.GetPdfObject(xrefIdx);
                                    PdfStream str = (PdfStream)(pdfObj);
                                    byte[] bytes = PdfReader.GetStreamBytesRaw((PRStream)str);

                                    string filter = tg.Get(PdfName.FILTER).ToString();
                                    string extension = "";
                                    if (filter == PdfName.DCTDECODE.ToString())
                                    {
                                        extension += PdfImageObject.ImageBytesType.JPG.FileExtension;
                                    }
                                    else if (filter == PdfName.JPXDECODE.ToString())
                                    {
                                        extension += PdfImageObject.ImageBytesType.JP2.FileExtension;
                                    }
                                    else if (filter == PdfName.FLATEDECODE.ToString())
                                    {
                                        extension += PdfImageObject.ImageBytesType.PNG.FileExtension;
                                    }
                                    else if (filter == PdfName.LZWDECODE.ToString())
                                    {
                                        extension += PdfImageObject.ImageBytesType.CCITT.FileExtension;
                                    }
                                    if ((bytes != null))
                                    {
                                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                                        sb.Append("<td><img id='image' style='height:100px;width:100px;' src='data:image/"+ extension + ";base64," + Convert.ToBase64String(bytes, 0, bytes.Length) + "' /></td>");
                                    }

                                    //iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance((PRIndirectReference)obj);
                                    //string filter = tg.Get(PdfName.FILTER).ToString();
                                    //if (filter == "/DCTDecode")
                                    //{
                                    //    System.Drawing.Image img2 = System.Drawing.Image.FromStream(new MemoryStream(bytes));

                                    //    var stream = new System.IO.MemoryStream();
                                    //    img2.Save(stream, ImageFormat.Jpeg);
                                    //    stream.Position = 0;
                                    //    PdfReader.KillIndirect(obj);
                                    //    img = iTextSharp.text.Image.GetInstance(stream);

                                    //    writer.AddDirectImageSimple(img, (PRIndirectReference)obj);                                       
                                    //}
                                }
                                else
                                {
                                    sb.Append("<td></td>");
                                }
                               
                            }
                        }
                    }
                    sb.AppendLine("</tr>");
                }
                sb.Append("</table>");
                stp.Writer.CloseStream = false;
                stp.Close();
                return sb.ToString();
            }
            else
                return null;
        }

        public void RenderImage(ImageRenderInfo renderInfo)
        {
            PdfImageObject image = renderInfo.GetImage();
            PdfName filter = (PdfName)image.Get(PdfName.FILTER);

            if (filter != null)
            {
                System.Drawing.Image drawingImage = image.GetDrawingImage();
                string extension = ".";
                if (filter == PdfName.DCTDECODE)
                {
                    extension += PdfImageObject.ImageBytesType.JPG.FileExtension;
                }
                else if (filter == PdfName.JPXDECODE)
                {
                    extension += PdfImageObject.ImageBytesType.JP2.FileExtension;
                }
                else if (filter == PdfName.FLATEDECODE)
                {
                    extension += PdfImageObject.ImageBytesType.PNG.FileExtension;
                }
                else if (filter == PdfName.LZWDECODE)
                {
                    extension += PdfImageObject.ImageBytesType.CCITT.FileExtension;
                }
                /* Rather than struggle with the image stream and try to figure out how to handle
                 * BitMapData scan lines in various formats (like virtually every sample I’ve found
                 * online), use the PdfImageObject.GetDrawingImage() method, which does the work for us. */
                //this.Images.Add(drawingImage, extension);
            }
        }
    }
}